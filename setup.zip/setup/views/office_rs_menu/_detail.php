									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Nama RS</label>
										<div class="col-md-9">
											: <span class="nama_rs"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Alamat</label>
										<div class="col-md-9">
											: <span class="alamat"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Provinsi</label>
										<div class="col-md-9">
											: <span class="provinsi"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Kab/Kota</label>
										<div class="col-md-9">
											: <span class="kota"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Kecamatan</label>
										<div class="col-md-9">
											: <span class="kecamatan"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Kode Pos</label>
										<div class="col-md-9">
											: <span class="kodepos"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Telp</label>
										<div class="col-md-9">
											: <span class="telp"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Fax</label>
										<div class="col-md-9">
											: <span class="fax"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Email</label>
										<div class="col-md-9">
											: <span class="email"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Website</label>
										<div class="col-md-9">
											: <span class="web"></span>
										</div>
									</div>
									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Logo</label>
										<div class="col-md-9">
											: <span class="logo"></span>
										</div>
									</div>

									