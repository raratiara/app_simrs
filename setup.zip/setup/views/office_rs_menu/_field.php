									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Nama RS <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtnamars;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Alamat </label>
										<div class="col-md-9">
											<?=$txtalamat;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Provinsi <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$selprovinsi;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kab/Kota </label>
										<div class="col-md-9">
											<?=$selkota;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kecamatan <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$selkec;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kode Pos </label>
										<div class="col-md-9">
											<?=$txtkodepos;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Telp </label>
										<div class="col-md-9">
											<?=$txttelp;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Fax <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtfax;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Email </label>
										<div class="col-md-9">
											<?=$txtemail;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Website <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtweb;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Logo </label>
										<div class="col-md-9">
											<?=$txtlogo;?>
										</div>
									</div>
