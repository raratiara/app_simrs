									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Nama Provinsi <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtprovinsi;?>
										</div>
									</div>
									