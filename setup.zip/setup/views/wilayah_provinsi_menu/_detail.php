									<div class="row">
										<label class="col-md-3 control-label no-padding-right">Nama Provinsi</label>
										<div class="col-md-9">
											: <span class="provinsi"></span>
										</div>
									</div>
									