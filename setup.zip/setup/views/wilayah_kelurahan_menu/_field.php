									
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Provinsi </label>
										<div class="col-md-9">
											<?=$selprovinsi;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kab/Kota <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$selkota;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kecamatan <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$selkecamatan;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kelurahan <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtkelurahan;?>
										</div>
									</div>