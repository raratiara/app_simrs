									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Kab/Kota <span class="required">*</span></label>
										<div class="col-md-9">
											<?=$txtkota;?>
										</div>
									</div>
									<div class="form-group">
										<label class="col-md-3 control-label no-padding-right">Provinsi </label>
										<div class="col-md-9">
											<?=$selprovinsi;?>
										</div>
									</div>